"""
URL configuration for chatbot project.
"""
from django.contrib import admin
from django.urls import path
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from . import views

# ADD THIS FUNCTION
def root_view(request):
    return JsonResponse({
        "message": "Chatbot API is running!",
        "endpoints": {
            "chat": "/api/chat/",
            "admin": "/admin/"
        },
        "usage": {
            "GET": "Get available threads",
            "POST": "Send message as form data or JSON"
        }
    })

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/chat/', views.ChatAPIView.as_view(), name='chat-api'),
    path('', root_view, name='root'),
]